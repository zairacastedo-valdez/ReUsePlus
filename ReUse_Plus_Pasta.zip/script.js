const STORAGE_KEY = "reuse_plus_database";

let objetos =
    JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];


/* ================= INICIAR ================= */

document.addEventListener("DOMContentLoaded", () => {

    atualizarSistema();

    configurarFiltros();

    configurarFormulario();

});



/* ================= FORMULÁRIO ================= */

function configurarFormulario() {

    document
        .getElementById("donationForm")
        .addEventListener(
            "submit",
            salvarObjeto
        );

}



/* ================= ABRIR MODAL ================= */

function abrirModal(id = null) {

    const modal =
        document.getElementById("modal");

    const form =
        document.getElementById("donationForm");

    form.reset();

    document.getElementById("objectId").value = "";


    if (id !== null) {

        const objeto =
            objetos.find(
                item => item.id === id
            );

        if (!objeto) return;


        document.getElementById(
            "modalTitle"
        ).textContent = "Editar objeto";


        document.getElementById(
            "objectId"
        ).value = objeto.id;


        document.getElementById(
            "objectName"
        ).value = objeto.nome;


        document.getElementById(
            "objectCategory"
        ).value = objeto.categoria;


        document.getElementById(
            "objectCondition"
        ).value = objeto.condicao;


        document.getElementById(
            "objectQuantity"
        ).value = objeto.quantidade;


        document.getElementById(
            "donor"
        ).value = objeto.doador;


        document.getElementById(
            "location"
        ).value = objeto.localizacao;


        document.getElementById(
            "image"
        ).value = objeto.imagem;


        document.getElementById(
            "description"
        ).value = objeto.descricao;

    } else {

        document.getElementById(
            "modalTitle"
        ).textContent = "Nova doação";

    }


    modal.classList.add("show");

}



/* ================= FECHAR MODAL ================= */

function fecharModal() {

    document
        .getElementById("modal")
        .classList.remove("show");

}



/* ================= SALVAR ================= */

function salvarObjeto(event) {

    event.preventDefault();


    const id =
        document.getElementById(
            "objectId"
        ).value;


    const dados = {

        nome:
            document.getElementById(
                "objectName"
            ).value.trim(),

        categoria:
            document.getElementById(
                "objectCategory"
            ).value,

        condicao:
            document.getElementById(
                "objectCondition"
            ).value,

        quantidade:
            Number(
                document.getElementById(
                    "objectQuantity"
                ).value
            ),

        doador:
            document.getElementById(
                "donor"
            ).value.trim(),

        localizacao:
            document.getElementById(
                "location"
            ).value.trim(),

        imagem:
            document.getElementById(
                "image"
            ).value.trim(),

        descricao:
            document.getElementById(
                "description"
            ).value.trim()

    };


    if (!dados.imagem) {

        dados.imagem =
            criarImagemPadrao(
                dados.nome
            );

    }


    /* EDITAR */

    if (id) {

        const index =
            objetos.findIndex(
                item =>
                    item.id === Number(id)
            );


        if (index !== -1) {

            objetos[index] = {

                ...objetos[index],

                ...dados

            };

            mostrarNotificacao(
                "Objeto atualizado com sucesso!"
            );

        }

    }

    /* NOVO */

    else {

        objetos.unshift({

            id: Date.now(),

            ...dados,

            status: "Disponível",

            interesses: 0,

            data:
                new Date().toISOString()

        });


        mostrarNotificacao(
            "Doação cadastrada com sucesso! 💜"
        );

    }


    salvarBanco();

    atualizarSistema();

    fecharModal();

}



/* ================= BANCO ================= */

function salvarBanco() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(objetos)
    );

}



/* ================= ATUALIZAR TUDO ================= */

function atualizarSistema() {

    atualizarResumo();

    renderizarObjetos();

    renderizarHistorico();

}



/* ================= RESUMO ================= */

function atualizarResumo() {

    const total =
        objetos.length;


    const disponiveis =
        objetos.filter(
            item =>
                item.status === "Disponível"
        ).length;


    const reservados =
        objetos.filter(
            item =>
                item.status === "Reservado"
        ).length;


    const doados =
        objetos.filter(
            item =>
                item.status === "Doado"
        ).length;


    document.getElementById(
        "totalObjects"
    ).textContent = total;


    document.getElementById(
        "availableObjects"
    ).textContent = disponiveis;


    document.getElementById(
        "reservedObjects"
    ).textContent = reservados;


    document.getElementById(
        "donatedObjects"
    ).textContent = doados;

}



/* ================= OBJETOS ================= */

function renderizarObjetos() {

    const grid =
        document.getElementById(
            "objectsGrid"
        );


    const busca =
        document.getElementById(
            "search"
        ).value.toLowerCase();


    const categoria =
        document.getElementById(
            "categoryFilter"
        ).value;


    const status =
        document.getElementById(
            "statusFilter"
        ).value;


    const filtrados =
        objetos.filter(objeto => {

            const pesquisa =
                objeto.nome
                    .toLowerCase()
                    .includes(busca) ||

                objeto.doador
                    .toLowerCase()
                    .includes(busca);


            const categoriaOK =
                !categoria ||
                objeto.categoria === categoria;


            const statusOK =
                !status ||
                objeto.status === status;


            return (
                pesquisa &&
                categoriaOK &&
                statusOK
            );

        });


    if (filtrados.length === 0) {

        grid.innerHTML = `

            <div class="empty">

                📦

                <h3 style="margin:10px 0;">
                    Nenhum objeto encontrado
                </h3>

                <p>
                    Cadastre uma nova doação
                    para começar.
                </p>

            </div>

        `;

        return;

    }


    grid.innerHTML =
        filtrados.map(objeto => `

            <article class="object-card">

                <img
                    class="object-image"
                    src="${escapar(objeto.imagem)}"
                    alt="${escapar(objeto.nome)}"
                >


                <div class="object-content">

                    <h3>
                        ${escapar(objeto.nome)}
                    </h3>


                    <div class="object-category">

                        ${escapar(objeto.categoria)}

                    </div>


                    <p class="object-description">

                        ${escapar(
                            objeto.descricao ||
                            "Sem descrição."
                        )}

                    </p>


                    <div class="object-info">

                        <span class="info">
                            📦 ${objeto.quantidade}
                        </span>

                        <span class="info">
                            ✨ ${escapar(objeto.condicao)}
                        </span>

                        <span class="info">
                            👤 ${escapar(objeto.doador)}
                        </span>

                    </div>


                    <div class="card-footer">

                        ${criarStatus(
                            objeto.status
                        )}


                        <div class="card-actions">

                            <button
                                class="action"
                                title="Demonstrar interesse"
                                onclick="
                                    demonstrarInteresse(
                                        ${objeto.id}
                                    )
                                "
                            >
                                ♡
                            </button>


                            <button
                                class="action"
                                title="Editar"
                                onclick="
                                    editarObjeto(
                                        ${objeto.id}
                                    )
                                "
                            >
                                ✎
                            </button>


                            <button
                                class="action"
                                title="Alterar status"
                                onclick="
                                    alterarStatus(
                                        ${objeto.id}
                                    )
                                "
                            >
                                ↻
                            </button>


                            <button
                                class="action delete"
                                title="Excluir"
                                onclick="
                                    excluirObjeto(
                                        ${objeto.id}
                                    )
                                "
                            >
                                🗑
                            </button>

                        </div>

                    </div>

                </div>

            </article>

        `).join("");

}



/* ================= FILTROS ================= */

function configurarFiltros() {

    document
        .getElementById("search")
        .addEventListener(
            "input",
            renderizarObjetos
        );


    document
        .getElementById("categoryFilter")
        .addEventListener(
            "change",
            renderizarObjetos
        );


    document
        .getElementById("statusFilter")
        .addEventListener(
            "change",
            renderizarObjetos
        );

}



/* ================= STATUS ================= */

function criarStatus(status) {

    const classe =
        status
            .toLowerCase()
            .normalize("NFD")
            .replace(
                /[\u0300-\u036f]/g,
                ""
            );


    return `

        <span class="status ${classe}">
            ${escapar(status)}
        </span>

    `;

}



/* ================= EDITAR ================= */

function editarObjeto(id) {

    abrirModal(id);

}



/* ================= EXCLUIR ================= */

function excluirObjeto(id) {

    const objeto =
        objetos.find(
            item => item.id === id
        );


    if (!objeto) return;


    const confirmar =
        confirm(
            `Deseja excluir "${objeto.nome}"?`
        );


    if (!confirmar) return;


    objetos =
        objetos.filter(
            item => item.id !== id
        );


    salvarBanco();

    atualizarSistema();


    mostrarNotificacao(
        "Objeto excluído."
    );

}



/* ================= STATUS ================= */

function alterarStatus(id) {

    const objeto =
        objetos.find(
            item => item.id === id
        );


    if (!objeto) return;


    const estados = [

        "Disponível",
        "Reservado",
        "Doado"

    ];


    const atual =
        estados.indexOf(
            objeto.status
        );


    objeto.status =
        estados[
            (atual + 1) %
            estados.length
        ];


    salvarBanco();

    atualizarSistema();


    mostrarNotificacao(
        `Status: ${objeto.status}`
    );

}



/* ================= INTERESSE ================= */

function demonstrarInteresse(id) {

    const objeto =
        objetos.find(
            item => item.id === id
        );


    if (!objeto) return;


    if (objeto.status !== "Disponível") {

        mostrarNotificacao(
            "Este objeto não está disponível."
        );

        return;

    }


    objeto.interesses =
        (objeto.interesses || 0) + 1;


    salvarBanco();


    mostrarNotificacao(
        "Interesse registrado! 💜"
    );

}



/* ================= HISTÓRICO ================= */

function renderizarHistorico() {

    const container =
        document.getElementById(
            "donationHistory"
        );


    if (objetos.length === 0) {

        container.innerHTML = `

            <div class="empty">

                Nenhuma doação cadastrada.

            </div>

        `;

        return;

    }


    container.innerHTML =
        objetos.map(objeto => `

            <div class="history-card">

                <img
                    src="${escapar(objeto.imagem)}"
                    alt="${escapar(objeto.nome)}"
                >


                <div class="history-info">

                    <h3>
                        ${escapar(objeto.nome)}
                    </h3>


                    <p>
                        👤 Doador:
                        ${escapar(objeto.doador)}
                    </p>


                    <p>
                        📦
                        ${escapar(objeto.categoria)}
                        •
                        ${objeto.quantidade}
                        unidade(s)
                    </p>


                    <span class="history-date">

                        ${formatarData(
                            objeto.data
                        )}

                    </span>

                </div>


                ${criarStatus(
                    objeto.status
                )}

            </div>

        `).join("");

}



/* ================= DATA ================= */

function formatarData(data) {

    return new Date(data)
        .toLocaleDateString(
            "pt-BR",
            {
                day: "2-digit",
                month: "2-digit",
                year: "numeric"
            }
        );

}



/* ================= IMAGEM PADRÃO ================= */

function criarImagemPadrao(nome) {

    const svg = `

        <svg
            xmlns="http://www.w3.org/2000/svg"
            width="600"
            height="400"
        >

            <rect
                width="100%"
                height="100%"
                fill="#111117"
            />

            <text
                x="50%"
                y="50%"
                text-anchor="middle"
                dominant-baseline="middle"
                fill="#b98cff"
                font-size="30"
                font-family="Arial"
            >
                ${nome}
            </text>

        </svg>

    `;


    return (
        "data:image/svg+xml;charset=UTF-8," +
        encodeURIComponent(svg)
    );

}



/* ================= SEGURANÇA ================= */

function escapar(texto) {

    if (
        texto === null ||
        texto === undefined
    ) {

        return "";

    }


    return String(texto)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}



/* ================= NOTIFICAÇÃO ================= */

function mostrarNotificacao(mensagem) {

    const notification =
        document.getElementById(
            "notification"
        );


    notification.textContent =
        mensagem;


    notification.classList.add(
        "show"
    );


    setTimeout(() => {

        notification.classList.remove(
            "show"
        );

    }, 2500);

}



/* ================= FECHAR MODAL ================= */

window.addEventListener(
    "click",
    event => {

        const modal =
            document.getElementById(
                "modal"
            );


        if (
            event.target === modal
        ) {

            fecharModal();

        }

    }
);